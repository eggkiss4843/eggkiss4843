---
title: "CAR-2020-04-001: Shadow Copy Deletion"
layout: analytic
submission_date: 2020/04/10
information_domain: Host
subtypes: Process
analytic_type: TTP
contributors: 
applicable_platforms: Windows
---


This analytic has been deprecated in favor of [CAR-2021-01-009](/analytics/CAR-2021-01-009), which covers the same technique with some additional detections.









